package Examen2014;

public class Personne {
    private int age;
    private int taille;
    private String nom;

    public Personne(int age, int taille, String nom) {
        this.age = age;
        this.taille = taille;
        this.nom = nom;
    }

    public int getAge() {
        return this.age;
    }

}
