package Examen2014;

public interface ConditionAcces {
    public boolean accesPossible(Personne p);
}