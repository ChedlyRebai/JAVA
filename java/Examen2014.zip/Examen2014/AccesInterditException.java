package Examen2014;

public class AccesInterditException extends Exception {
    public AccesInterditException(String errorMessage) {
        super(errorMessage);
    }
}
